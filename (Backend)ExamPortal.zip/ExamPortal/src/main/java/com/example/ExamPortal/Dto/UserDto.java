package com.example.ExamPortal.Dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDto {
    @NotNull(message = "username should not be null")
    private String userName;
    private String password;
    @NotNull(message = "firstname should not be null")
    private String firstName;
    @NotNull(message = "lastname should not be null")
    private String lastName;
    @Email(message = "enter valid email address")
    private String emailId;
    @Pattern(regexp = "^\\d{10}$",message = "enter 10 digit")
    private String mobileNo;
    private long roleId;
}
