package com.example.ExamPortal.Service;

import com.example.ExamPortal.Dto.QuizzDto;
import com.example.ExamPortal.Entity.Category;
import com.example.ExamPortal.Entity.Quizz;
import com.example.ExamPortal.Repository.CategoryRepository;
import com.example.ExamPortal.Repository.QuizzRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuizzService {
    @Autowired
    QuizzRepository quizzRepository;
    @Autowired
    CategoryRepository categoryRepository;

    public Quizz addQuiz(QuizzDto quizzDto)
    {
        Quizz quiz=new Quizz();
        quiz.setQuizTitle(quizzDto.getQuizTitle());
        quiz.setDescription(quizzDto.getDescription());
        quiz.setMaxMarks(quizzDto.getMaxMarks());
        quiz.setNoOfQuestion(quizzDto.getNoOfQuestion());
      quiz.setCategory(categoryRepository.getReferenceById(quizzDto.getCategoryId()));
        return quizzRepository.save(quiz);
    }
    public List<Quizz> getAllQuiz() {


        return quizzRepository.findAll();

    }

    public Quizz getQuiz(long id)
    {
        return quizzRepository.findById(id).get();
    }

    public Quizz updateQuiz(QuizzDto quizzDto, long id) {
        Quizz quizz = quizzRepository.findById(id).get();
        quizz.setQuizTitle(quizzDto.getQuizTitle());
        quizz.setDescription(quizzDto.getDescription());
        quizz.setMaxMarks(quizzDto.getMaxMarks());
        quizz.setNoOfQuestion(quizzDto.getNoOfQuestion());
        quizz.setCategory(categoryRepository.getReferenceById(quizzDto.getCategoryId()));
       return quizzRepository.save(quizz);

    }

    public void deleteQuiz( long id)
    {
        quizzRepository.deleteById(id);
    }

    public List<Quizz> getCatwiseQuiz(long categoryId) {
        return quizzRepository.findByCategoryCategoryId(categoryId);
    }





}
