package com.example.ExamPortal.Service;

import com.example.ExamPortal.Dto.CategoryDto;
import com.example.ExamPortal.Dto.QuestionDto;
import com.example.ExamPortal.Entity.Category;
import com.example.ExamPortal.Entity.Question;
import com.example.ExamPortal.Repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryService {
    @Autowired
    CategoryRepository categoryRepository;

    public Category addCategory(CategoryDto categoryDto)
    {
        Category category=new Category();
        category.setCategoryName(categoryDto.getCategoryName());
        category.setDescription(categoryDto.getDescription());
        return categoryRepository.save(category);
    }


    public List<Category> getAllCategory()
    {
        return categoryRepository.findAll();
    }

    public Category getCategory(long id)
    {
        return categoryRepository.findById(id).get();
    }

    public void deleteCategory(long id) {
        categoryRepository.deleteById(id);
    }

    public Category updateCategory(CategoryDto categoryDto, long id)
    {
           Category category=categoryRepository.findById(id).get();
            category.setCategoryName(categoryDto.getCategoryName());
            category.setDescription(categoryDto.getDescription());
            return categoryRepository.save(category);
    }
}
