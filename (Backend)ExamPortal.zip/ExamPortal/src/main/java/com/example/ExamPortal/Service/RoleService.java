package com.example.ExamPortal.Service;


import com.example.ExamPortal.Dto.RoleDto;
import com.example.ExamPortal.Entity.Role;
import com.example.ExamPortal.Repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class RoleService {
    @Autowired
    RoleRepository roleRepository;


    public Role addRole(RoleDto roleDto) {
        Role role=new Role();
        role.setRoleName(roleDto.getRoleName());
        return roleRepository.save(role);
    }


    public Role getRole(long id) {
        return roleRepository.findById(id).get();
    }
}
