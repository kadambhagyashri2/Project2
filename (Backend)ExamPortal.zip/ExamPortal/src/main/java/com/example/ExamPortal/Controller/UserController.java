package com.example.ExamPortal.Controller;


import com.example.ExamPortal.Dto.UserDto;
import com.example.ExamPortal.Entity.User;
import com.example.ExamPortal.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
public class UserController {


    @Autowired
    private UserService userService;
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @PostMapping("/Users")
    public User addUsers(@RequestBody UserDto userDto) {
        return userService.addUsers(userDto);
    }

    @GetMapping("/users")
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/users/{id}")
    public User getUser(@PathVariable long id) {
        return userService.getUser(id);
    }
    @GetMapping("/users/{userName}/{password}")
    public User getLoggedUser(@PathVariable String userName ,@PathVariable String password)
    {
        return  userService.getLoggedUser(userName,password);
    }




}