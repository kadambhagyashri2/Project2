package com.example.ExamPortal.Controller;

import com.example.ExamPortal.Dto.QuestionDto;
import com.example.ExamPortal.Entity.Question;
import com.example.ExamPortal.Service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController

public class QuestionController {
    @Autowired
    QuestionService questionService;

@PostMapping("/questions")
    public Question addQuestions(@RequestBody QuestionDto questionDto)
    {
        return questionService.addQuestions(questionDto);
    }
    @GetMapping("/question")
    public List<Question> getAllQuestion()
    {
        return questionService.getAllQuesttion();
    }
    @GetMapping("/question/{id}")
    public Question getQuestion(@PathVariable long id)
    {
        return questionService.getQuestion(id);

    }
    @GetMapping("/question/QuizWiseQuestion/{quizId}")
public List<Question> getQuizzesQuestion(@PathVariable long quizId)
{
    return questionService.getQuizWiseQuestion(quizId);
}

    @PutMapping("/question/{id}")
    public Question updateQuestion(@RequestBody QuestionDto questionDto,@PathVariable long id)
    {
        return questionService.updateQuestion(questionDto,id);
    }

    @DeleteMapping("question/{id}")
    public void deleteQuestion(@PathVariable long id)
    {
        questionService.deleteQuestion(id);
    }

//@PostMapping("/eval-quiz")
//    public ResponseEntity<?> evalQuiz(@RequestBody List<Question> questions)
//{
//    System.out.println(questions);
//    return ResponseEntity.ok("got question with answer");
//}
}
