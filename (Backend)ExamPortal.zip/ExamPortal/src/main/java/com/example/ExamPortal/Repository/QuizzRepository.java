package com.example.ExamPortal.Repository;

import com.example.ExamPortal.Entity.Category;
import com.example.ExamPortal.Entity.Quizz;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@EnableJpaRepositories
public interface QuizzRepository extends JpaRepository<Quizz,Long> {
    List<Quizz> findByCategoryCategoryId(long categoryId);
}
