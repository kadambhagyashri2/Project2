package com.example.ExamPortal.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Quizz
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long quizId;
    private String quizTitle;
    private String description;
    private String maxMarks;
    private String noOfQuestion;

    @ManyToOne()
    @JoinColumn(name = "categoryId")
//    @JsonIgnore
    private Category category;


}
