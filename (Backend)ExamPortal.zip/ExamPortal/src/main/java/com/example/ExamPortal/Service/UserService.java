package com.example.ExamPortal.Service;

import com.example.ExamPortal.Dto.UserDto;
import com.example.ExamPortal.Entity.User;
import com.example.ExamPortal.Repository.RoleRepository;
import com.example.ExamPortal.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    UserRepository userRepository;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    PasswordEncoder passwordEncoder;

    public User addUsers(UserDto userDto)
    {
        User user=new User();
        user.setUserName(userDto.getUserName());
    user.setPassword(passwordEncoder.encode(userDto.getPassword()));
    user.setFirstName(userDto.getFirstName());
    user.setLastName(userDto.getLastName());
    user.setEmailId(userDto.getEmailId());
    user.setMobileNo(userDto.getMobileNo());
    user.setRole(roleRepository.getReferenceById(userDto.getRoleId()));
    return userRepository.save(user);
    }

    public List<User> getAllUsers() {

        return userRepository.findAll();
    }

    public User getUser(long id) {
        return userRepository.findById(id).get();
    }


    public User getLoggedUser(String userName, String password) {
        User user = userRepository.findByUserName(userName);
        if (user != null && passwordEncoder.matches(password, user.getPassword())) {
            return user;
        } else {
            return null;
        }
    }
}
