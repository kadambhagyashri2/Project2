package com.example.ExamPortal.Service;

import com.example.ExamPortal.Dto.QuestionDto;
import com.example.ExamPortal.Entity.Question;
import com.example.ExamPortal.Repository.QuestionRepository;
import com.example.ExamPortal.Repository.QuizzRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class QuestionService {
    @Autowired
    QuestionRepository questionRepository;
@Autowired
    QuizzRepository quizzRepository;
    public Question addQuestions(QuestionDto questionDto)
    {
        Question question=new Question();
        question.setContent(questionDto.getContent());
        question.setOption1(questionDto.getOption1());
        question.setOption2(questionDto.getOption2());
        question.setOption3(questionDto.getOption3());
        question.setOption4(questionDto.getOption4());
        question.setAnswer(questionDto.getAnswer());
       question.setQuizz(quizzRepository.getReferenceById(questionDto.getQuizId()));
        return questionRepository.save(question);
    }

    public List<Question> getAllQuesttion()
    {
        return questionRepository.findAll();
    }

    public Question getQuestion(long id) {
        return questionRepository.findById(id).get();
    }
    public Question updateQuestion(QuestionDto questionDto, long id)
    {
        Question question=questionRepository.findById(id).get();
        question.setContent(questionDto.getContent());
        question.setOption1(questionDto.getOption1());
        question.setOption2(questionDto.getOption2());
        question.setOption3(questionDto.getOption3());
        question.setOption4(questionDto.getOption4());
        question.setAnswer(questionDto.getAnswer());
        question.setQuizz(quizzRepository.getReferenceById(questionDto.getQuizId()));
        return questionRepository.save(question);
    }

    public void deleteQuestion(long id)
    {
        questionRepository.deleteById(id);
    }

    public List<Question> getQuizWiseQuestion(long quizId) {
        return questionRepository.findByQuizzQuizId(quizId);
    }

//    public Question getQuestionOfQuizForTest(long id) {
//        return questionRepository.
//    }




}
