package com.example.ExamPortal.Controller;


import com.example.ExamPortal.Dto.RoleDto;
import com.example.ExamPortal.Entity.Role;
import com.example.ExamPortal.Entity.User;
import com.example.ExamPortal.Service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
public class RoleController {

    @Autowired
	RoleService roleService;
	@PostMapping("/role")
	public Role addRole(@RequestBody RoleDto roleDto)
	{
		return roleService.addRole(roleDto);
	}
	@GetMapping("/role")
	public Role getRole(@PathVariable long id)
	{
		return roleService.getRole(id);
	}



}
