package com.example.ExamPortal.Controller;

import com.example.ExamPortal.Dto.QuizzDto;
import com.example.ExamPortal.Entity.Category;
import com.example.ExamPortal.Entity.Quizz;
import com.example.ExamPortal.Service.QuizzService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class QuizzController {
    @Autowired
    QuizzService quizzService;

    @PostMapping("/quiz")
    public Quizz addQuiz(@RequestBody QuizzDto quizzDto)
    {
        return quizzService.addQuiz(quizzDto);
    }

    @GetMapping("/quiz")
    public List<Quizz> getAllQuiz()
    {
        return quizzService.getAllQuiz();
    }

    @GetMapping("/quiz/{id}")
    public Quizz getQuiz(@PathVariable long id)
    {
        return quizzService.getQuiz(id);
    }

    @PutMapping("/quiz/{id}")
    public Quizz updateQuiz(@RequestBody QuizzDto quizzDto,@PathVariable long id)
    {
        return quizzService.updateQuiz(quizzDto,id);
    }

    @DeleteMapping("/quiz/{id}")
    public void  deleteQuiz(@PathVariable long id)
    {
         quizzService.deleteQuiz(id);
    }
    @GetMapping("/quiz/CatWiseQuiz/{categoryId}")
    public List<Quizz> getQuizzesCategory(@PathVariable long categoryId)
    {
        return quizzService.getCatwiseQuiz(categoryId);
    }
}
