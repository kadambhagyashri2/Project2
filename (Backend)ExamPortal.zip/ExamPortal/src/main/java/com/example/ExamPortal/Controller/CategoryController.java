package com.example.ExamPortal.Controller;

import com.example.ExamPortal.Dto.CategoryDto;
import com.example.ExamPortal.Dto.QuestionDto;
import com.example.ExamPortal.Entity.Category;
import com.example.ExamPortal.Entity.Question;
import com.example.ExamPortal.Service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CategoryController {
    @Autowired
    CategoryService categoryService;
    @PostMapping("/category")
    public Category addCategory(@RequestBody CategoryDto categoryDto)
    {
        return categoryService.addCategory(categoryDto);
    }
    @GetMapping("/categories")
    public List<Category> getAllCategory()
    {
        return categoryService.getAllCategory();
    }
    @GetMapping("/category/{id}")
    public Category getCategory(@PathVariable long id)
    {
        return categoryService.getCategory(id);
    }
    @PutMapping("/category/{id}")
    public Category updateCategory(@RequestBody CategoryDto categoryDto, @PathVariable long id)
    {
        return categoryService.updateCategory(categoryDto,id);
    }
    @DeleteMapping("/category/{id}")
    public void  deleteCategory(@PathVariable long id)
    {
        categoryService. deleteCategory(id);
    }
}
