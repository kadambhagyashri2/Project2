import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/Services/login.service';
import Swal from 'sweetalert2';

@Component({
selector: 'app-login',
templateUrl: './login.component.html',
styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
constructor(private loginService:LoginService,private router:Router) { }
userName:any='';
password:any='';
ngOnInit(){
}

login() {
 this.loginService.getLoggedUser(this.userName,this.password).subscribe(
  (user:any)=>{
    this.loginService.setUser(user);
    console.log(user);
    if(user.role.roleId==2)
    {
      this.router.navigate(['/user-dashboard/0']);
      this.loginService.loginSubject.next(true);
    }
   else if(user.role.roleId==1)
    {
      this.router.navigate(['/admin-dashboard']);
      this.loginService.loginSubject.next(true);
    }
    else{ 
    }
  },
  (error: any) => {
    console.log(error);
    Swal.fire({
      icon: 'error',
      title: 'Invalid Details',
      text: 'Please enter a valid username and password',
    });
  }
);
}
}







   
   
   
   
   
   
   
// if(this.loginData.username.trim()==''||this.loginData==null)
// {
// Swal.fire({
// icon: 'error',
// title: 'Oops...',
// text: 'Username is Required!',
// })
// }
// if(this.loginData.password.trim()==''||this.loginData==null)
// {
// Swal.fire({
// icon: 'error',
// title: 'Oops...',
// text: 'Password is Required!',
// })
// }
// this.loginService.generateToken(this.loginData).subscribe((data:any)=>{
// console.log("success");
// console.log(data);
// //login..
// this.loginService.loginUser(data.token);
// this.loginService.getCurrentUser().subscribe(
// (user:any)=>{
// this.loginService.setUser(user);
// console.log(user);
// if(this.loginService.getUserRole()=="ADMIN")
// {
// this.router.navigate(['admin-dashboard']);
// this.loginService.loginStatusSubject.next(true);
// }
// else if(this.loginService.getUserRole()=="USER")
// {
// this.router.navigate(['user-dashboard/AllQuizzes']);
// this.loginService.loginStatusSubject.next(true);
// }
// else
// {
// this.loginService.logout();
// }
// });
// },
// err=>{
// Swal.fire({
// icon: 'error',
// title: 'Oops...',
// text: 'Invalid Login Details,Try again!!',
// });
// });
// }
// }
