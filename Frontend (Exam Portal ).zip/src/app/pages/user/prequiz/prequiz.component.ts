import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { QuizServicesService } from 'src/app/Services/quiz-services.service';
import Swal from 'sweetalert2';


@Component({
selector: 'app-prequiz',
templateUrl: './prequiz.component.html',
styleUrls: ['./prequiz.component.css']
})
export class PrequizComponent implements OnInit {

qid:any;
quiz:any;
constructor(private route:ActivatedRoute,private _quiz:QuizServicesService,private router:Router) { }

ngOnInit(): void {
this.qid=this.route.snapshot.params['quizId'];
this._quiz.getQuiz(this.qid).subscribe((data:any)=>{
  console.log(data);
  this.quiz=data;
},err=>{
alert("Something went wrong");
})
}

startQuiz()
{
Swal.fire({
title: 'Do you want to Start the Quiz?',
showCancelButton: true,
confirmButtonText: 'Start',
icon:'info'
}).then((result) => {
if (result.isConfirmed) {
this.router.navigate(['/start-quiz/quizId']);
// +this.quizId
} 
})
}
starttest()
{
  Swal.fire({
    title: "Do you want to start the quiz?",
    showCancelButton: true,
    confirmButtonText: "Start",
    denyButtonText: `Cancel`,
    icon:"info"
  }).then((result:any) => {
    if (result.isConfirmed) {
     this.router.navigate(['/start-quiz/quizId'])
    } else if (result.isDenied) {
      Swal.fire("Changes are not saved", "", "info");
    }
  });
}
onButtonClick(quizId: number) {
 
    console.log('Button clicked with quizId:', quizId);
    this.router.navigate(['/start-quiz',quizId]); 
  
  }
}
