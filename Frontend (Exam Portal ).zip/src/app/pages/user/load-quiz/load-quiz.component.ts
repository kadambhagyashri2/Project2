import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { QuestionsServiceService } from 'src/app/Services/questions-service.service';
import { QuizServicesService } from 'src/app/Services/quiz-services.service';
import Swal from 'sweetalert2';

@Component({
selector: 'app-load-quiz',
templateUrl: './load-quiz.component.html',
styleUrls: ['./load-quiz.component.css']
})
export class LoadQuizComponent implements OnInit {
// catId: any;
// quizzes:any;
// constructor(private route:ActivatedRoute,private quiz:QuizServicesService) { }

// ngOnInit(): void {
// this.catId=this.route.snapshot.params['catId'];
// this.route.params.subscribe((params)=>{
// this.catId=params['catId'];
// if(this.catId=="AllQuizzes")
// {
// this.quiz.getActiveQuizzes().subscribe(
// (data:any)=>{
// this.quizzes=data;
// })
// }
// else
// {
// this.quiz.getActiveQuizzesOfCategory(this.catId).subscribe((data:any)=>{
// this.quizzes=data;
// },err=>{
// alert("Somyhinh went wrong")
// });
// }

// });

// }

// }
constructor(private activeRoute:ActivatedRoute,private quizService:QuizServicesService,private router:Router,private _question:QuestionsServiceService){}
public catid:any;
public quizes:any;
public categoryId:any;

ngOnInit(): void {

this.activeRoute.params.subscribe(params=>{

this.catid=params['categoryId'];
 if(this.catid==0)
  {
    console.log("load all quizzes");
    this.quizService.getQuizzes().subscribe(
  (data:any)=>{
    this.quizes=data;
    console.log(this.quizes);
  },
  (error)=>{
    Swal.fire("error")
  });
}
  else{
    console.log("load specific quiz");
    this.quizService.getQuzziesCategory(this.catid).subscribe(
      (data:any)=>{
        this.quizes=data;
        console.log("quiz data",this.quizes);
      },
      (error)=>{
        console.log(error);
        Swal.fire('Error',"error in loading quiz data",'error')
      });
    
  }
});
}
onButtonClick(quizId: number) {

  console.log('Button clicked with quizId:', quizId);
  this.router.navigate(['/user-dashboard/instructions',quizId]); 
}
}

 
 
