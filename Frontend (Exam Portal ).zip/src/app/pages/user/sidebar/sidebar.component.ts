import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CategoryServiceService } from 'src/app/Services/category-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-sidebar-user',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  // categories: any;
  public categories=[{
  categoryId:'',
  categoryName:'',
}];
  constructor(private cat:CategoryServiceService,private router: Router) { }

  ngOnInit(): void {
    this.cat.getCategories().subscribe(
    (data:any)=>{
     this.categories=data;
     console.log("categories",data); 
    },
    (err)=>{
    Swal.fire('Oh!Sorry','please try again','error');
    });
  }
  onButtonClick(categoryId: number) {
    
    console.log('Button clicked with categoryId:', categoryId);
    this.router.navigate(['/user-dashboard', categoryId]); 
  }
}
