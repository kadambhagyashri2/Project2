import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/Services/user.service';
import Swal from 'sweetalert2';

@Component({
selector: 'app-signup',
templateUrl: './signup.component.html',
styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
    // form:FormGroup=new FormGroup({
    //     email:new FormControl("",[Validators.required,this.EmailValidators])
    // })
    public user={
        userName:'',
        password:'',
        firstName:'',
        lastName:'',
        emailId:'',
        mobileNo:'',
        roleId:2,
      };

// getError(control:any):string{
//     if(control.errors?.required && control.touched)
//     return 'This field is requried';
// else
// if(control.errors?.emailError && control.touched)
// return 'plez enter valid email id...'
// else return '';
// }
// EmailValidators(control:AbstractControl)
// {
//     const pattern=/^\w+@[a-zA-Z]+?\.[a-zA-Z]{2,20}$/;
//     const value=control.value;
//     if(pattern.test(value) && control.touched)
//     return{
// emailError:true
// }
// else return null;
// }
constructor(private userService:UserService) { }

ngOnInit(): void {
    
}

formSubmit()
{
// if(this.user.userName==''|| this.user==null)
// {
// Swal.fire({
// icon: 'error',
// title: 'Oops...',
// text: 'Username is Required!',
// })
// return;
// }

// this.userService.addUser(this.user).subscribe((data)=>{

// this.user.firstName='';
// this.user.lastName='';
// this.user.emailId='';
// this.user.userName='';
// this.user.password='';
// this.user.mobileNo='';
// Swal.fire('Success','You have succesfully registered','success');
// },
// err=>{
// Swal.fire({
// icon: 'error',
// title: 'Oops...',
// text: 'Username is already Exist,please try another Username!',
// })
// });

// }
console.log(this.user);
if(this.user.userName=='')
{
  Swal.fire({
    icon: 'error',
    title: 'Username Required',
    text: 'Please enter username',
  });
   return;
}
this.userService.addUser(this.user).subscribe((data)=>{
  console.log(data)
  Swal.fire({
    icon: 'success',
    title: 'Success',
    text: 'Data Successfully Fetch',
  });
},
(error: any) => {
  console.log(error);
  Swal.fire({
    icon: 'error',
    title: 'Error Occurred'
  });
}
);
}
}
