import { Component, OnInit } from '@angular/core';
import { CategoryServiceService } from 'src/app/Services/category-service.service';
import { QuizServicesService } from 'src/app/Services/quiz-services.service';
import Swal from 'sweetalert2';

@Component({
selector: 'app-view-quizzes',
templateUrl: './view-quizzes.component.html',
styleUrls: ['./view-quizzes.component.css']
})
export class ViewQuizzesComponent implements OnInit {
    quizzes=[
        {
          quizId:'',
          quizTitle:'',
          description:'',
          maxMarks:'',
          noOfQuestion:'',
          category:{
            categoryId:'',
            categoryName:''
            }
        },
];

constructor(private quiz:QuizServicesService) { }

ngOnInit(): void {
this.quiz.getQuizzes().subscribe((data:any)=>{
this.quizzes=data;
},
err=>{
Swal.fire("Error in Loading Data")
});
}

//delete Quiz
deleteQuiz(quizId: any)
{

Swal.fire({
icon:'info',
title:'Are You Sure?',
confirmButtonText:'Delete',
showCancelButton:true
}).then(result=>{
if(result.isConfirmed)
{
this.quiz.deleteQuiz(quizId).subscribe(
(data)=>{
this.quizzes=this.quizzes.filter((quiz)=>quiz.quizId!=quizId);
Swal.fire('Success','Successfully Deleted','success');
},
err=>{
Swal.fire('error','Something went wrong','error')
});
}

});
}

}
