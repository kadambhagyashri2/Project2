import { Component, OnInit } from '@angular/core';
import { CategoryServiceService } from 'src/app/Services/category-service.service';
import Swal from 'sweetalert2';

@Component({
selector: 'app-add-category',
templateUrl: './add-category.component.html',
styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent implements OnInit {
    public category={
        categoryId:'',
        categoryName:' ',
        description:' ',
      };
constructor(private _category:CategoryServiceService) { }

ngOnInit(): void {
}
submitForm()
{
if(this.category.categoryName.trim()==''||this.category.description.trim()==''||this.category==null)
{
Swal.fire({
icon: 'error',
title: 'Oops...',
text: 'All fields are Required!',
})
return;
}
this._category.addCategories(this.category).subscribe(
(data:any)=>{
this.category.categoryName='';
this.category.description='';
Swal.fire('Success','Category added successfully','success');
},
(err:any)=>{
Swal.fire({
 icon: 'error',
 title: 'Oops...',
 text: 'Something went wrong!',
 })
});
}


}
