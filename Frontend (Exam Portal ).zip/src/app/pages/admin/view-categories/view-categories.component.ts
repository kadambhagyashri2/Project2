import { Component, OnInit } from '@angular/core';
import { CategoryServiceService } from 'src/app/Services/category-service.service';
import Swal from 'sweetalert2';

@Component({
selector: 'app-view-categories',
templateUrl: './view-categories.component.html',
styleUrls: ['./view-categories.component.css']
})
export class ViewCategoriesComponent implements OnInit {
    categories=[
        {
          categoryId:'',
          categoryName:'',
          description:''
        },
      ];
constructor(private categoryService:CategoryServiceService) { }

ngOnInit(): void {
this.categoryService.getCategories().subscribe(
(data:any)=>{
this.categories=data;
console.log(this.categories);
},
(error:any)=>{
  console.log(error)
Swal.fire('Error Occured','Error in loading data','error')
});
}

}
