import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { QuestionsServiceService } from 'src/app/Services/questions-service.service';
import Swal from 'sweetalert2';

@Component({
selector: 'app-view-quiz-questions',
templateUrl: './view-quiz-questions.component.html',
styleUrls: ['./view-quiz-questions.component.css']
})
export class ViewQuizQuestionsComponent implements OnInit {

  public quizId:any
  public quizTitle: any;
questions=[
  {
    questionId:'',
    content:'',
    option1:'',
    option2:'',
    option3:'',
    option4:'',
    answer:'',
    quizz:{
      quizId:'',
      quizTitle:'',
      }
  },
 ];

constructor(private route:ActivatedRoute,private _question:QuestionsServiceService) { }

ngOnInit(): void {
this.quizId=this.route.snapshot.params['quizId'];
this.quizTitle=this.route.snapshot.params['quizTitle'];

// this._question.getQuizQuestions(this.quizId).subscribe(
//   (data: any) => {
//     this.questions = data;
//   },
//   (error) => {
//     console.error("error");
//     Swal.fire ("An error occurred");
//   }
// );
// }
this._question.getQuizQuestions(this.quizId).subscribe(
  (data: any) => {
    this.questions = data;
  },
  (error) => {
    console.error("error");
    Swal.fire ("An error occurred");
  }
);
}
//Delete Question
deleteQuestion(questionId:any)
{
  Swal.fire({
   icon:'info',
    showCancelButton:true,
    confirmButtonText:'Delete',
    title:'Are You Sure,Do you want to delete this question'
    }).then(result=>{
    if(result.isConfirmed)
    {
  this._question.deleteQuestion(questionId).subscribe(
    (data)=>{
      Swal.fire('success',"Question deleted successfully");
  },
  (error)=>
  {
    console.log(error);
    Swal.fire('Error',"Question not deleted");
  });
  }
  
});
   
 }
}