import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baseUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class QuizServicesService {

  constructor(private http:HttpClient) { }
  
  //get all quizzes
  public  getQuizzes()
  {
    return this.http.get("http://localhost:8080/quiz");
  }
  //addQuiz()
  public addQuiz(quiz: any)
  {
  return this.http.post(`${baseUrl}/quiz/`,quiz)
  }
  //delteQuiz
  public deleteQuiz(quizId:any)
  {
  return this.http.delete(`${baseUrl}/quiz/${quizId}`);
  }
  //get the single quiz
  public getQuiz(quizId:any)
  {
  return this.http.get(`${baseUrl}/quiz/${quizId}`);
  }
  //update quiz
  public updateQuiz(quiz: any)
  {
  return this.http.put(`${baseUrl}/quiz/`,quiz)
  }
  //get quizzes of category
  public getQuzziesCategory(categoryId:any)
  {
   return this.http.get(`http://localhost:8080/quiz/CatWiseQuiz/${categoryId}`);
  }
 
}
