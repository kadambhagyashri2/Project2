import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baseUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class QuestionsServiceService {

  constructor(private http:HttpClient) { }
  //getQuestion of quiz this can use admin
  
  public getQuizQuestions(quizId:any)
  {
    return this.http.get(`http://localhost:8080/question/QuizWiseQuestion/${quizId}`);
  }
  //get question for test, this is for user
  public getQuestion(questionId:any)
  {
  return this.http.get(`${baseUrl}/question/${questionId}`);
  }
 
  //add Question
  public addQuestion(question: any)
  {
  return this.http.post(`${baseUrl}/questions/`,question);
  }

  public deleteQuestion(questionId:any)
  {
     return this.http.delete(`http://localhost:8080/question/${questionId}`);
  }
  
  public evalQuiz(questions:any)
  {
    return this.http.post(`http://localhost:8080/eval-quiz/`,questions);
  }
}
